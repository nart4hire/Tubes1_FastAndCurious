package za.co.entelect.challenge.command;

public interface Command {
    String render();
}
