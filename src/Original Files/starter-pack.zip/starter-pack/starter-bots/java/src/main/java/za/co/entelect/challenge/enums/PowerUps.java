package za.co.entelect.challenge.enums;

import com.google.gson.annotations.SerializedName;

public enum PowerUps {
    @SerializedName("BOOST")
    BOOST,
    @SerializedName("OIL")
    OIL
}
