class Position:
    def __init__(self, y, x):
        self.lane = y
        self.block = x
