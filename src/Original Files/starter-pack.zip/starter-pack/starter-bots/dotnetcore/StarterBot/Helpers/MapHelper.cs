using System;
using System.Collections.Generic;
using System.Text;
using StarterBot.Entities;
using StarterBot.Enums;

namespace StarterBot.Helpers
{
    public static class MapHelper
    {

        public static bool getNextBlocks(MapPosition targetMapPosition, int mapSize)
        {
            return true;
        }
    }
}
