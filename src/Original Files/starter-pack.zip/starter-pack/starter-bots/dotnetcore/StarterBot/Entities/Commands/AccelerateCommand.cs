namespace StarterBot.Entities.Commands
{
    public class AccelerateCommand: ICommand
    {
        public string RenderCommand()
        {
            return "ACCELERATE";
        }
    }
}
