namespace StarterBot.Entities.Commands
{
    public class BoostCommand: ICommand
    {
        public string RenderCommand()
        {
            return "USE_BOOST";
        }
    }
}
