namespace StarterBot.Entities.Commands
{
    public class OilCommand: ICommand
    {
        public string RenderCommand()
        {
            return "USE_OIL";
        }
    }
}
