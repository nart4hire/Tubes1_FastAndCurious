namespace StarterBot.Entities
{
    public class MapPosition
    {
        public int Y { get; set; }
        public int X { get; set; }
    }
}