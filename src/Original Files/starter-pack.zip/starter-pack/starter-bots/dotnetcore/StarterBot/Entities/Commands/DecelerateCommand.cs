namespace StarterBot.Entities.Commands
{
    public class DecelerateCommand: ICommand
    {
        public string RenderCommand()
        {
            return "DECELERATE";
        }
    }
}
