namespace StarterBot.Entities.Commands
{
    public interface ICommand
    {
        string RenderCommand();
    }
}
