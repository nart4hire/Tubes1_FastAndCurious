namespace StarterBot.Enums
{
    public enum PlayerIdentifier
    {
        A,
        B
    }
}