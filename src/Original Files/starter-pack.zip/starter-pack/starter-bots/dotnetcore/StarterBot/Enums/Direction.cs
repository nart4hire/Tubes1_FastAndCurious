using System.ComponentModel;

namespace StarterBot.Enums
{
    public enum Direction
    {
        LEFT,
        RIGHT
    }
}
