using System.ComponentModel;

namespace StarterBot.Enums
{
    public enum CellType
    {
        EMPTY,
        MUD, 
        OIL_SPILL,
        OIL_POWER,
        FINISH,
        BOOST

    }


}
